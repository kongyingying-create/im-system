package com.platform.imsystem.server;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.group.ChannelGroup;
import io.netty.channel.group.DefaultChannelGroup;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import io.netty.util.concurrent.GlobalEventExecutor;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class ImMessageHandler extends SimpleChannelInboundHandler<TextWebSocketFrame> {

    // 在线用户通道管理
    public static final ChannelGroup onlineChannels = new DefaultChannelGroup(GlobalEventExecutor.INSTANCE);
    public static final Map<String, ChannelHandlerContext> userChannelMap = new ConcurrentHashMap<>();

    private final StringRedisTemplate redisTemplate;
    private final RabbitTemplate rabbitTemplate;

    // 无参构造（解决你之前的报错）
    public ImMessageHandler() {
        this.redisTemplate = null;
        this.rabbitTemplate = null;
    }

    // Spring 注入
    public ImMessageHandler(StringRedisTemplate redisTemplate, RabbitTemplate rabbitTemplate) {
        this.redisTemplate = redisTemplate;
        this.rabbitTemplate = rabbitTemplate;
    }

    // ====================== 收到消息 ======================
    @Override
    protected void channelRead0(ChannelHandlerContext ctx, TextWebSocketFrame msg) {
        String content = msg.text();
        System.out.println("收到消息：" + content);

        // 1. 如果用户还没登录 → 第一条消息当作用户ID
        if (!userChannelMap.containsValue(ctx)) {
            String userId = content;
            userChannelMap.put(userId, ctx);
            onlineChannels.add(ctx.channel());

            // 存入 Redis → 在线用户
            if (redisTemplate != null) {
                redisTemplate.opsForValue().set("online:" + userId, "true");
            }

            System.out.println("用户登录：" + userId);
            ctx.channel().writeAndFlush(new TextWebSocketFrame("登录成功！欢迎用户：" + userId));
            return;
        }

        // 2. 普通消息 → 转发全体 + 存入MQ
        sendToAll(content);
        sendToMq(content);
    }

    // ====================== 转发给所有人 ======================
    private void sendToAll(String msg) {
        onlineChannels.writeAndFlush(new TextWebSocketFrame("广播消息：" + msg));
    }

    // ====================== 发送到 RabbitMQ ======================
    private void sendToMq(String msg) {
        if (rabbitTemplate != null) {
            rabbitTemplate.convertAndSend("im_exchange", "im.key", msg);
        }
    }

    // ====================== 连接建立 ======================
    @Override
    public void channelActive(ChannelHandlerContext ctx) {
        System.out.println("新客户端连接：" + ctx.channel().id());
    }

    // ====================== 断开连接 ======================
    @Override
    public void channelInactive(ChannelHandlerContext ctx) {
        System.out.println("客户端断开：" + ctx.channel().id());

        // 从在线列表移除
        onlineChannels.remove(ctx.channel());
        // 下面这行是修复后的正确代码！
        userChannelMap.entrySet().removeIf(entry -> entry.getValue().equals(ctx));
    }

    // ====================== 异常 ======================
    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
        cause.printStackTrace();
        ctx.close();
    }
}