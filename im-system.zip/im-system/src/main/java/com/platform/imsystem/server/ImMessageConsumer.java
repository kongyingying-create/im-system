package com.platform.imsystem.server;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class ImMessageConsumer {

    @RabbitListener(queues = "im_queue")
    public void receive(String msg) {
        System.out.println("【MQ消费】收到消息：" + msg);
    }
}