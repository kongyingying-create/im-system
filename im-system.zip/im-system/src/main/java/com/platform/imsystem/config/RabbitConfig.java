package com.platform.imsystem.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitConfig {

    public static final String EXCHANGE = "im_exchange";
    public static final String QUEUE = "im_queue";
    public static final String ROUTING_KEY = "im.key";

    @Bean
    public DirectExchange imExchange() {
        return new DirectExchange(EXCHANGE);
    }

    @Bean
    public Queue imQueue() {
        return new Queue(QUEUE);
    }

    @Bean
    public Binding binding() {
        return BindingBuilder.bind(imQueue()).to(imExchange()).with(ROUTING_KEY);
    }
}