package com.platform.imsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
